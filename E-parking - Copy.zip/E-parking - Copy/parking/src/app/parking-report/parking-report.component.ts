import { Component, OnInit } from '@angular/core';
import { ParkingService } from "../parking.service";
import { parkingModel } from "../parking-user-report/parking.model";
import { Router } from "@angular/router";

@Component({
  selector: 'app-parking-report',
  templateUrl: './parking-report.component.html',
  styleUrls: ['./parking-report.component.css']
})
export class ParkingReportComponent implements OnInit {
  parking:parkingModel[];
  title:string="Parking details";
  constructor(private parkingservice:ParkingService,private router:Router) { }
  deleteItem= new parkingModel(null,null,null,null,null);
  ngOnInit(): void {
    this.parkingservice.getProducts().subscribe((data)=>{
      this.parking=JSON.parse(JSON.stringify(data));
    })
  }

  deleteproduct(_id){
    if (confirm("Are you delete the iteam")==true) {
      console.log("done");
      console.log(_id);
      this.parkingservice.deleteProducts(_id)
      .subscribe();
      this.parkingservice.getProducts()
      .subscribe((data)=>{
        this.parking=JSON.parse(JSON.stringify(data))
        this.router.navigate(['/parking-user-report'])
        
      })
    }
  }
}
