import { Component, OnInit } from '@angular/core';
import { ParkingService } from "../parking.service";
import { parkingModel } from "../parking-user-report/parking.model";
import { Router } from "@angular/router";

@Component({
  selector: 'app-enter-parking',
  templateUrl: './enter-parking.component.html',
  styleUrls: ['./enter-parking.component.css']
})
export class EnterParkingComponent implements OnInit {
  title:string="Welcome to E-parking....";

  constructor(private parkingService:ParkingService ,private router:Router) { }
  parkingItem= new parkingModel(null,null,null,null,null);

  ngOnInit(): void {
  }
  addvehicle(){
    this.parkingService.newParking(this.parkingItem);
    console.log("called");
    this.router.navigate(['/parking-user-report']);

  }

}
