import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnterParkingComponent } from './enter-parking.component';

describe('EnterParkingComponent', () => {
  let component: EnterParkingComponent;
  let fixture: ComponentFixture<EnterParkingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnterParkingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterParkingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
