import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private _registerurl="http://localhost:3000/register";
  private _loginurl="http://localhost:3000/login";
  private _loginadminurl="http://localhost:3000/adminlogin";
  constructor(private http:HttpClient) { }
  registeruser(user){
    console.log(user);
    return this.http.post(this._registerurl,user);
  
  }
  loginuser(user){
    return this.http.post(this._loginurl,user);
  }
  adminlogin(user){
    return this.http.post(this._loginadminurl,user);
  }
}
