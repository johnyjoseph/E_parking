import { Component, OnInit } from '@angular/core';
import { UserService } from "../user.service";
import { userModel } from "../user-details/user.model";
import { Router } from "@angular/router";

@Component({
  selector: 'app-add-new-user',
  templateUrl: './add-new-user.component.html',
  styleUrls: ['./add-new-user.component.css']
})
export class AddNewUserComponent implements OnInit {
  title:string="Add new User";

  constructor(private userService:UserService ,private router:Router) { }
  productItem= new userModel(null,null,null,null,null);

  ngOnInit(): void {
  }
  addproduct(){
    this.userService.newProduct(this.productItem);
    console.log("called");
    this.router.navigate(['/user-details']);

  }

}
