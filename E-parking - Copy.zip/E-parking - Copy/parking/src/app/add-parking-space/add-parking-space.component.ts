import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-parking-space',
  templateUrl: './add-parking-space.component.html',
  styleUrls: ['./add-parking-space.component.css']
})
export class AddParkingSpaceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
