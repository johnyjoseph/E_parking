import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { UserService } from "../user.service";
import { userModel } from "./user.model";

@Component({
  selector: 'app-user-details',
  templateUrl: './user-details.component.html',
  styleUrls: ['./user-details.component.css']
})
export class UserDetailsComponent implements OnInit {


  user:userModel[];
  constructor(private userService:UserService,private router:Router) { }
  title='User details'

  deleteItem= new userModel(null,null,null,null,null);

  ngOnInit(): void {
    this.userService.getProducts().subscribe((data)=>{
      this.user=JSON.parse(JSON.stringify(data));
    })
  }




  deleteproduct(_id){
    if (confirm("Are you delete the iteam")==true) {
      console.log("done");
      console.log(_id);
      this.userService.deleteProducts(_id)
      .subscribe();
      this.userService.getProducts()
      .subscribe((data)=>{
        this.user=JSON.parse(JSON.stringify(data))
        this.router.navigate(['/user-details'])
        
      })
    }
 

  }

}
