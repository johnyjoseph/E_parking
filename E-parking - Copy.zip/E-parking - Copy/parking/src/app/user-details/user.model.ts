export class userModel{
    constructor(
       public name:String,
       public email:String,
       public phone_number:Number,
       public username: String,
       public password: String 
    ){}}
