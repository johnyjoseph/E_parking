import { Component, OnInit } from '@angular/core';
import { ParkingService } from "../parking.service";
import { Router } from "@angular/router";
import { parkingModel } from "../parking-user-report/parking.model";

@Component({
  selector: 'app-exitparking',
  templateUrl: './exitparking.component.html',
  styleUrls: ['./exitparking.component.css']
})
export class ExitparkingComponent implements OnInit {
  parking:parkingModel[];
  constructor(private parkingservice:ParkingService,private router:Router) { }
  deleteItem= new parkingModel(null,null,null,null,null);
  ngOnInit(): void {
    this.parkingservice.getProducts().subscribe((data)=>{
      this.parking=JSON.parse(JSON.stringify(data));
    })
  }

  deleteproduct(_id){
    if (confirm("Are you delete the iteam")==true) {
      console.log("done");
      console.log(_id);
      this.parkingservice.deleteProducts(_id)
      .subscribe();
      this.parkingservice.getProducts()
      .subscribe((data)=>{
        this.parking=JSON.parse(JSON.stringify(data))
        this.router.navigate(['/parking-user-report'])
        
      })
    }
  }
}
