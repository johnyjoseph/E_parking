import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class ParkingService {
  constructor( private http:HttpClient) { }
  getProducts(){
    return this.http.get("http://localhost:3000/parking");
  }
  newParking(item){
    return this.http.post("http://localhost:3000/insert",{"parking":item})
    .subscribe((data)=>{console.log(data)})
  }
  deleteProducts(_id){
    return this.http.post("http://localhost:3000/delete",{"id":_id})
  }
  UpProduct(ID,UpItem){

    return this.http.post("http://localhost:3000/update",{"parking":UpItem,"ID":ID})
    .subscribe((data)=>{console.log(data)})
    
   }
   Upget(ID){
  
    console.log(ID)
    return this.http.post("http://localhost:3000/uplist",{"ID":ID})
    
  }
  buttonvalue(test){
    console.log(test);
    return test;
  }
}