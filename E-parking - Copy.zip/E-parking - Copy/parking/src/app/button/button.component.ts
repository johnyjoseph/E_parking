import { Component, OnInit } from '@angular/core';
import { ParkingService } from "../parking.service";

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.css']
})
export class ButtonComponent implements OnInit {
buttonclick(test){
  console.log(test);
  this.parkingservise.buttonvalue(test);

}

  constructor(private parkingservise:ParkingService) { }
 
  ngOnInit(): void {
  }

}
