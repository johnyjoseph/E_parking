import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  constructor( private http:HttpClient) { }
  getProducts(){
    return this.http.get("http://localhost:3000/users");
  }
  newProduct(item){
    return this.http.post("http://localhost:3000/addnew",{"userd":item})
    .subscribe((data)=>{console.log(data)})
  }
  deleteProducts(_id){
    return this.http.post("http://localhost:3000/del",{"id":_id})
  }
  UpProduct(ID,UpItem){

    return this.http.post("http://localhost:3000/update",{"product":UpItem,"ID":ID})
    .subscribe((data)=>{console.log(data)})
    
   }
   Upget(ID){
  
    console.log(ID)
    return this.http.post("http://localhost:3000/uplist",{"ID":ID})
    
  }
}
