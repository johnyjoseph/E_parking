import { Component, OnInit } from '@angular/core';
import { ParkingService } from "../parking.service";
import { parkingModel } from "../parking-user-report/parking.model";
import { Router } from "@angular/router";
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

  constructor(private parkingService:ParkingService , private router :Router,private _route:ActivatedRoute) { }
  UpItem=  new parkingModel(null,null,null,null,null);
  title:string="Update the list";

  // updateproduct(){
  //   this.productService.newProduct(this.productItem);
  //   console.log("called");
  //   this.router.navigate(['/product']);

  // }

  ngOnInit(): void {
    let id=this._route.snapshot.paramMap.get("id")
    const ID={id:id};
    this.parkingService.Upget(ID)
    .subscribe((data)=>{this.UpItem=JSON.parse(JSON.stringify(data)); })


  }
  UProduct(){

    let id=this._route.snapshot.paramMap.get("id")
    const ID={id:id};
    console.log(ID);
    this.parkingService.UpProduct(ID,this.UpItem)
    
    alert('Successfully updated');
    this.router.navigate(['/parking-user-report'])
  }
    
  }



