import { Component, OnInit } from '@angular/core';
import { AuthService } from "../auth.service";
import { Router } from "@angular/router";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginuserdetails={
    username:'',
    password:''
  }
  constructor( private _auth:AuthService , private _router:Router) { }
  loginuser(){
    console.log(this.loginuserdetails);

    this._auth.loginuser(this.loginuserdetails)
    .subscribe(
      res=>this._router.navigate(['/userdash']),
      err=>console.log(err)
    )
    // this._auth.loginuser(this.loginuserdetails)
    // .subscribe(
    //   res=>{
    //     localStorage.setItem('token',res['token'])
    //     this._router.navigate(["/special-events"])
    //   },
    //   err=>console.log(err)
    // )
  }

  ngOnInit(): void {
  }

  }
