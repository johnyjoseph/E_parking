export class parkingModel{
    constructor(
     
        public slotno:String,
        public vehicleno:String,
        public entrytime:Date,
        public exittime:Date,
        public parkingcharge:Number,
        
    ){}}