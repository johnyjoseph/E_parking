import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkingUserReportComponent } from './parking-user-report.component';

describe('ParkingUserReportComponent', () => {
  let component: ParkingUserReportComponent;
  let fixture: ComponentFixture<ParkingUserReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParkingUserReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParkingUserReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
