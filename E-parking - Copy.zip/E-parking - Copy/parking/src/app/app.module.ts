import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { IndexComponent } from './index/index.component';

import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserDetailsComponent } from './user-details/user-details.component';
import { AddNewUserComponent } from './add-new-user/add-new-user.component';
import { AddParkingSpaceComponent } from './add-parking-space/add-parking-space.component';
import { ParkingReportComponent } from './parking-report/parking-report.component';

import { ParkingSpaceDetailsComponent } from './parking-space-details/parking-space-details.component';
import { ParkingUserReportComponent } from './parking-user-report/parking-user-report.component';
import { ExitparkingComponent } from './exitparking/exitparking.component';
import { EnterParkingComponent } from './enter-parking/enter-parking.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UsernavComponent } from './usernav/usernav.component';
import { UpdateComponent } from './update/update.component';
import { ButtonComponent } from './button/button.component';
import { AuthService } from "./auth.service";
import { ParkingService } from "./parking.service";
import { HomeComponent } from './home/home.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';

@NgModule({
  declarations: [
    AppComponent,
    IndexComponent,
  
    LoginComponent,
  
    RegisterComponent,
  
    DashboardComponent,
  
    UserDetailsComponent,
  
    AddNewUserComponent,
  
    AddParkingSpaceComponent,
  
    ParkingReportComponent,
  
  
  
    ParkingSpaceDetailsComponent,
  
    ParkingUserReportComponent,
  
    ExitparkingComponent,
  
    EnterParkingComponent,
  
    UserdashComponent,
  
    UsernavComponent,
  
    UpdateComponent,
  
    ButtonComponent,
  
    HomeComponent,
  
    AdminloginComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [AuthService,ParkingService],
  bootstrap: [AppComponent]
})
export class AppModule { }
