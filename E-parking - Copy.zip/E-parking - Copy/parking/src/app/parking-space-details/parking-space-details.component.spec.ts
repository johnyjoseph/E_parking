import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParkingSpaceDetailsComponent } from './parking-space-details.component';

describe('ParkingSpaceDetailsComponent', () => {
  let component: ParkingSpaceDetailsComponent;
  let fixture: ComponentFixture<ParkingSpaceDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParkingSpaceDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ParkingSpaceDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
