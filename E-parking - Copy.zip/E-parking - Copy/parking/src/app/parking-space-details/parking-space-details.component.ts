import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parking-space-details',
  templateUrl: './parking-space-details.component.html',
  styleUrls: ['./parking-space-details.component.css']
})
export class ParkingSpaceDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
