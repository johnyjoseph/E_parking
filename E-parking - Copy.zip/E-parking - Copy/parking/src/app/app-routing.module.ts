import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { LoginComponent } from "./login/login.component";
import { RegisterComponent } from "./register/register.component";
import { UserDetailsComponent } from './user-details/user-details.component';
import { AddNewUserComponent } from './add-new-user/add-new-user.component';
import { AddParkingSpaceComponent } from './add-parking-space/add-parking-space.component';
import { ParkingReportComponent } from './parking-report/parking-report.component';
import { ParkingSpaceDetailsComponent } from './parking-space-details/parking-space-details.component';
import { ParkingUserReportComponent } from './parking-user-report/parking-user-report.component';
import { ExitparkingComponent } from './exitparking/exitparking.component';
import { EnterParkingComponent } from './enter-parking/enter-parking.component';
import { UserdashComponent } from './userdash/userdash.component';
import { UpdateComponent } from './update/update.component';
import { ButtonComponent } from './button/button.component';
import { HomeComponent } from './home/home.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { DashboardComponent } from './dashboard/dashboard.component';




const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path:"login",
  component:LoginComponent  },
  {
    path:"adminlogin",
    component:AdminloginComponent
  },
 {
   path:"register",
   component:RegisterComponent
 },
 {
   path:"dashboard",
   component:DashboardComponent,children:[
     
  {
    path:"user-details",
    component:UserDetailsComponent
  },
  {
    path:"add-new-user",
    component:AddNewUserComponent
  },
  {
    path:"add-parking-space",
    component:AddParkingSpaceComponent
  },
  {
    path:"parking-report",
    component:ParkingReportComponent
  },
  {
    path:"parking-space-details",
    component:ParkingSpaceDetailsComponent
  }
  



   ]
  },
  

  {
    path:"userdash",
    component:UserdashComponent ,children:[
      {
        path:"parking-user-report",
       component:ParkingUserReportComponent
      },
      {
        path:"button",
        component:ButtonComponent ,children:[
          
        ]
         

        
      },
          
          {
            path:"exitparking",
            component:ExitparkingComponent 
          },
         

        ]},
     
        {
          path:'update/:id',
          component:UpdateComponent
        },
        {path:"enter-parking",
        component:EnterParkingComponent
        }
      
        

 


];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
