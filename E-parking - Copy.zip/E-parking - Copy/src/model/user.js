const mongoose=require("mongoose");
mongoose.connect('mongodb://localhost:27017/E-Parking');
const Schema=mongoose.Schema;
const UserSchema = new Schema({
    name:String,
    email:String,
    phone_number:Number,
    username: String,
    password: String  
});
 var userdata=mongoose.model('userdata',UserSchema);
 module.exports=userdata;

