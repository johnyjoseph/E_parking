const mongoose = require('mongoose');
// mongoose.connect('mongodb://localhost:27017/ProductDb');
const Schema = mongoose.Schema;
var NewParkingSchema = new Schema({
    
    slotno: String,
    vehicleno: String,
    entrytime: Date,
    exittime: Date,
    parkingcharge:String
});
var Parkingdata = mongoose.model('parking',NewParkingSchema);
module.exports = Parkingdata;
