const express=require('express');
var bodyparser = require('body-parser');
const cors = require('cors');
const parkingdata=require("./src/model/parkingdata")
var app = new express();
app.use(bodyparser.json());
app.use(cors());
const userdata = require('./src/model/user');
const User=require('./src/model/user');



app.get('/users',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    userdata.find()
    .then(function(users){
        res.send(users);
    })
});
app.post('/addnew',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    var userd = {
        name : req.body.userd.name,
        email : req.body.userd.email,
        phone_number : req.body.userd.phone_number,
        username : req.body.userd.username,
        password : req.body.userd.password
        
    }
    var userd = new userdata (userd);
    userd.save();
})


    
app.post('/del',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    id=req.body.id;
    userdata.findByIdAndDelete({_id:id})
    .then(()=>{
        console.log("Deleted successfully");
        userdata.find()
        .then((user)=>{
            res.send(user);
        })
    })

})





app.post('/register',(req,res)=>{
    let userdata=req.body;

    let user =new User(userdata);
   res.send(user)
    user.save((err,registerduser)=>{
        if (err) {
            console.log("error in register page");            
        }
        else{
            res.status(200).send(registerduser);
        }
    })
})


app.post('/adminlogin',(req,res)=>{
    let userdata=req.body;
    console.log("server"+userdata);
    User.findOne({username:userdata.username},(err,user)=>{
        if (userdata.username=="admin" && userdata.password=="123") {
            console.log("admin");
            res.status(200).send(user);
            
        }
        else{
            console.log("error in username"+err);
        }
     
        // if (err) {
        //     console.log("error in username"+err);

            
        // }
        //  else {
        //     if (!user) {
        //         res.status(401).send("invalid username");
                
        //     } 
            // else {
            // if (user.password !== userdata.password)  {
            //         res.status(401).send("invalid password"); 
            //     }
            //     else{
            //         // let payload={subject:user._id}
            //         // let token=jwt.sign(payload,'secretkey')
        
            //         res.status(200).send(user);
            //     }
            // }   
        //  }
    })

})



app.post('/login',(req,res)=>{
    let userdata=req.body;
    User.findOne({username:userdata.username},(err,user)=>{
     
        if (err) {
            console.log("error in username"+err);
            
        }
         else {
            if (!user) {
                res.status(401).send("invalid username");
                
            } 
            else {
            if (user.password !== userdata.password)  {
                    res.status(401).send("invalid password"); 
                }
                else{
                    // let payload={subject:user._id}
                    // let token=jwt.sign(payload,'secretkey')
        
                    res.status(200).send(user);
                }
            }   
         }
    })
})


app.post('/update',(req,res)=>{
    id=req.body.ID.id;
    console.log(id);
    
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Methods: GET, POST,PUT, PATCH, DELETE, OPTIONS");

   

      parkingdata.findByIdAndUpdate({_id:id},{
        slotno:req.body.parking.slotno,
        vehicleno:req.body.parking.vehicleno,
        entrytime:req.body.parking.entrytime,
        exittime:Date(),
        parkingcharge:req.body.parking.parkingcharge,     
    },(err,doc)=>{if(err)console.log(err)} )
    

   
    })


app.post('/uplist',(req,res)=>{

    console.log("uplist")
    id=req.body.ID.id;
    console.log(id);
    parkingdata.findById({_id:id}).then((parking)=>{res.send(parking)});

})


app.get('/parking',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    parkingdata.find()
    .then(function(parking){
        res.send(parking);
    })
});



app.post('/insert',function(req,res){
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    let ts = Date.now();
    let dd =new Date(ts);
    let hour=dd.getHours();
    let minute=dd.getMinutes();
    var parking = {
        slotno : req.body.parking.slotno,
        vehicleno : req.body.parking.vehicleno,
        entrytime :dd ,
        exittime : req.body.parking.exittime,
        parkingcharge : req.body.parking.parkingcharge
    }
    var parking = new parkingdata (parking);
    parking.save();
})



    
app.post('/delete',(req,res)=>{
    res.header("Access-Control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    id=req.body.id;
    parkingdata.findByIdAndDelete({_id:id})
    .then(()=>{
        console.log("Deleted successfully");
        parkingdata.find()
        .then((parking)=>{
            res.send(parking);
        })
    })

})


app.listen(3000,function(){
    console.log("listening to port 3000");
});

